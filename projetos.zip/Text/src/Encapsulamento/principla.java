package Encapsulamento;

public class principla {

	public static void main(String[] args) {
		
	}

}
