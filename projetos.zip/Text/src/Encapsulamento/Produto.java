package Encapsulamento;

public class Produto {

}
